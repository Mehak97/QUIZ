blankspaces = ["_0_", "_1_", "_2_", "_3_", "_4_"] # the  no. of fill ups present in each level
easy_para =" _0_ is the capital of India.India has _1_ total number of states and\n _2_ number of union teritories.The mother tongue\n of India is _3_._4_ is national animal of India."
easy_ans=['delhi','29','7','hindi','tiger'] #list of answers for easy level
medium_para ="_0_ became the winner of Bigg Boss 10.Priyanka Chopra started her holywood career with _1_.\nDangal movie in the biopic of _2_.Kholi's first captaincy was against _3_.Chennai's chief Minister _4_ who died due to heart attack"
medium_ans=["manveer","quantico","mahavir phogat","england","jayalalithaa"] # list ofanswers for medium level
hard_para ="_0_ CEO of google.Indian cricketer _1_ who fought against cancer._2_ became the president of USA.\n_3_ is known as the Pink City of India.The name of Indian Space Center is _4_"
hard_ans=["sundar pichai","yuvraj singh","donald trump","jaipur","ISRO"]  # list of answers for hard level
trial=3
input=2
def try_again(answers,index,paragraph):
            print "fill the correct option ... You have 3 trial"
            chance=0
            while(chance<trial):
                answer1=raw_input() #user is asked to again input if entered answer was wrong
                if(answer1==answers[index]):
                    print "YOU GOT IT RIGHT!!!!!!!!!!!!"
                    paragraph=paragraph.replace(blankspaces[index],answers[index])
                    print paragraph
                    break
                else:
                    print "SORRY!!!!! ...again enter your choice"
                    chance=chance+1
            if(chance>input):
                print "SORRY YOU COULDN'T ANSWER IT RIGHT .... the correct answer was "+answers[index]
                paragraph=paragraph.replace(blankspaces[index],answers[index])
            index=index+1
            return (paragraph,index)
def play_game(paragraph,answers): # here starts the  level entere by user . in this the selected level's paragraph and answers are passed
                                  #inputs(paragraph and answers)
                                  # outputs(returns the qiuz with blanks replaced)
    print "Let's start the game.." # game starts here
    print paragraph
    index=0
    count=0
    for blanks in answers:
      print "Fill the answer of "+str(index)
      answer1=raw_input()  # user is prompted to enter his answer
      if(answer1==answers[index]): #matching of answer is done
            print "correct answer you scored a point..."
            paragraph=paragraph.replace(blankspaces[index],answers[index]) # here blank gets replaced by the answer
            print paragraph
            count=count+1
            index=index+1
      else:
          paragraph,index = try_again(answers,index,paragraph)
    print "CONGRATULATIONS..... YOUR TOTAL SCORE IS "+str(count)+"\n" # here final score is printed
    print "\t\t................Thanks for taking this quiz....................."  # quiz gets ended     
def quit(): # here is the option for user
    print "Do you wish to continue [yes/no]????"
    reply=raw_input() # user is asked whether he wishes to continue the quiz or end it
    if(reply=='no'):
        print "Thanks for taking this quiz.."
        exit(0)  # quiz gets ended
    else:
        start() # if user wishes to continue the quiz starts again
def start():
        print "Hello!! Welcome to the world of quizzes...."
        print "Let's get started with it..."
        print "Choose your level of difficulty,which are:-\n    1.EASY      2.MEDIUM     3.HARD"  
        print "Enter the level"
        list_of_levels =['EASY','MEDIUM','HARD']
        value=raw_input() #user is prompted to choose the level of quiz
        if(list_of_levels[0]==value.upper()): # if easy level is opted
             play_game(easy_para,easy_ans) # in this paragraph and answer list is send
             quit() # here user is asked whether he wish to continue the game or stop it
        if(list_of_levels[1]==value.upper()):  # if medium level is opted
             play_game(medium_para,medium_ans) # in this paragraph and answer list is send
             quit() # here user is asked whether he wish to continue the game or stop it
        if(list_of_levels[2]==value.upper()):  # if hard level is opted
             play_game(hard_para,hard_ans) # in this paragraph and answer list is send
             quit()  # here user is asked whether he wish to continue the game or stop it
        else:
             print "choose your level correctly...." # level entered is wrong
while(1):
    start()  #here starts the quiz game
            
